<footer class='p-5 border-t bg-base-100 border-b border-base-300'>
    <div class="text-center">
        <div class="container mx-auto flex justify-between items-center text-sm text-center font-semibold">
            <span>Jl. Sudirman No. 38 E - Limo Kaum, Batusangkar</span>
            <span>Made by Ivan Hanifdeal</span>
        </div>
    </div>
</footer>